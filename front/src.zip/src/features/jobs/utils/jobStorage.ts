import type { Job } from '../../../types/job'

const JOBS_STORAGE_KEY = 'ai-job-tracker-jobs'

export function loadJobsFromStorage(): Job[] | null {
  const storedJobs = localStorage.getItem(JOBS_STORAGE_KEY)

  if (!storedJobs) {
    return null
  }

  return JSON.parse(storedJobs) as Job[]
}

export function saveJobsToStorage(jobs: Job[]) {
  localStorage.setItem(JOBS_STORAGE_KEY, JSON.stringify(jobs))
}