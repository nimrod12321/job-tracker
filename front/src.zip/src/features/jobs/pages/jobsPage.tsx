import { useState, useEffect } from 'react';
import type { Job, JobStatus } from '../../../types/job';
import JobCard from '../components/JobCard';
import JobForm from '../components/JobForm';
import { mockJobs } from '../data/mockJobs';
import {
  loadJobsFromStorage,
  saveJobsToStorage,
} from '../utils/jobStorage'

function JobsPage() {
  const [isFormVisible, setIsFormVisible] = useState(false);
  const [jobs, setJobs] = useState<Job[]>(() => {
    const storedJobs = loadJobsFromStorage()

    return storedJobs ?? mockJobs
    })

  useEffect(() => {
  saveJobsToStorage(jobs)
}, [jobs])

  function handleAddJob(newJob: Job) {
    setJobs((currentJobs) => [newJob, ...currentJobs]);
    setIsFormVisible(false);
  }

  function handleDeleteJob(jobId: string) {
    setJobs((currentJobs) => currentJobs.filter((job) => job.id !== jobId));
  }

  function handleUpdateJobStatus(jobId: string, status: JobStatus) {
    setJobs((currentJobs) =>
      currentJobs.map((job) =>
        job.id === jobId ? { ...job, status } : job,
      ),
    );
  }

  return (
    <section>
      <div className="page-header">
        <div>
          <h1>Jobs</h1>
          <p>Manage your job applications and track their status.</p>
        </div>
        <button
          type="button"
          aria-expanded={isFormVisible}
          aria-controls="job-form"
          onClick={() => setIsFormVisible((isVisible) => !isVisible)}
        >
          {isFormVisible ? 'Cancel' : 'Add Job'}
        </button>
      </div>

      {isFormVisible && <JobForm onAddJob={handleAddJob} />}

      <div className="job-grid">
        {jobs.map((job) => (
          <JobCard
            key={job.id}
            job={job}
            onDeleteJob={handleDeleteJob}
            onChangeStatus={handleUpdateJobStatus}
          />
        ))}
      </div>
    </section>
  );
}

export default JobsPage;
