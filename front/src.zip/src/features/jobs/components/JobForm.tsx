import { useState, type FormEvent } from 'react';
import type { Job, JobStatus } from '../../../types/job';

type JobFormProps = {
  onAddJob: (job: Job) => void;
};

const statusOptions: JobStatus[] = [
  'applied',
  'HR',
  'technical',
  'rejected',
  'offer',
];

function JobForm({ onAddJob }: JobFormProps) {
  const [company, setCompany] = useState('');
  const [position, setPosition] = useState('');
  const [status, setStatus] = useState<JobStatus>('applied');
  const [wantedSalary, setWantedSalary] = useState<number>(0);
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const today = new Date().toISOString().split('T')[0];

    const newJob: Job = {
      id: crypto.randomUUID(),
      company,
      position,
      status,
      wantedSalary,
      location,
      createdAt: today,
      updatedAt: today,
      notes,
    };

    onAddJob(newJob);
  }

  return (
    <form id="job-form" className="job-form" onSubmit={handleSubmit}>
      <h2>Add Job</h2>
      <label>
        Company
        <input
          value={company}
          onChange={(event) => setCompany(event.target.value)}
          required
        />
      </label>
      <label>
        Position
        <input
          value={position}
          onChange={(event) => setPosition(event.target.value)}
          required
        />
      </label>
      <label>
        Status
        <select
          value={status}
          onChange={(event) => setStatus(event.target.value as JobStatus)}
        >
          {statusOptions.map((statusOption) => (
            <option key={statusOption} value={statusOption}>
              {statusOption}
            </option>
          ))}
        </select>
      </label>
      <label>
        Wanted salary
        <input
          type="number"
          value={wantedSalary}
          onChange={(event) => setWantedSalary(Number(event.target.value))}
          required
        />
      </label>
      <label>
        Location
        <input
          value={location}
          onChange={(event) => setLocation(event.target.value)}
          required
        />
      </label>
      <label>
        Notes
        <textarea
          value={notes}
          onChange={(event) => setNotes(event.target.value)}
        />
      </label>
      <button type="submit">Add Job</button>
    </form>
  );
}

export default JobForm;
